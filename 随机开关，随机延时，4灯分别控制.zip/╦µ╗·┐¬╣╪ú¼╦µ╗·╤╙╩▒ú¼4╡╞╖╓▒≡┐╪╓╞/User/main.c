#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include<stdlib.h>
int main(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_All;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	int i=0;
	int d=0;
	srand(0);
	while (1)
	{ 
		i=rand()%512;
		d=rand()%1001;
		i=rand()%4096;
		if(i>2047)  //ͨ��ȡ��ת�����Ʋ�������Ӧ��LED��
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_11);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_11);
						}
		if(i%2048>1023)  
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_10);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_10);
						}
		if(i%1024>511)  
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_9);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_9);
						}
		if(i%512>255)  
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_0);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_0);
						}
		if(i%256>127)  
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_1);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_1);
						}
						if(i%128>63)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_2);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_2);
						}
						if(i%64>31)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_3);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_3);
						}
						if(i%32>15)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_4);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_4);
						}
						if(i%16>7)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_5);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_5);
						}
						if(i%8>3)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_6);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_6);
						}
						if(i%4>1)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_7);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_7);
						}
						if(i%2>0)
						{
							GPIO_SetBits(GPIOA, GPIO_Pin_8);
						}else
						{
							GPIO_ResetBits(GPIOA, GPIO_Pin_8);
						}
						Delay_ms(d);
	}
}
