#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int main(void)
{
	OLED_Init();
	int a=1;
	int b=2;
	int c=3;
	int d=4;
	int i=0;
	while (1)
	{
		while(i<13)
		{
		OLED_ShowString(a, 1, "Happy   ");
				OLED_ShowString(b, 1, "mother's");
			OLED_ShowString(c, 1, "day!");
		OLED_ShowString(d, 1, "          ");
		Delay_ms(500);
	a++;
		b++;
		c++;
		d++;
		i++;
		if(a==5)
			a=1;
		if(b==5)
			b=1;
		if(c==5)
			c=1;
		if(d==5)
			d=1;
	}
		a=1;
	b=1;
	c=1;
		while(i<46)
		{
			OLED_ShowString(1, a, "Happy           ");
				OLED_ShowString(2, b, "mother's        ");
			OLED_ShowString(3, c, "day!            ");		
		Delay_ms(250);
	a++;
		b++;
		c++;		
		i++;
		if(a==17)
			a=1;
		if(b==17)
			b=1;
		if(c==17)
			c=1;		
		}
		a=1;
		b=2;
		c=3;
		d=4;
		i=0;
		OLED_ShowString(2, 1, "              ");
	}
}
