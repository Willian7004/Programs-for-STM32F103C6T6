#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int main(void)
{
	OLED_Init();
	
	int a=1;
	int b=1;
	int c=0;
	
	while (1)
	{
		OLED_ShowNum(a, b, c, 1);
		b++;
		c++;
		if(b==15)
		{
			b=1;
			a++;
		}
		if(c==10)
		{
			c=0;
		}
		if(a==5)
		{
			a=1;
		}
		Delay_ms(50);
	}
}
