#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int main(void)
{
	OLED_Init();
	
	int a=0;
	int b=10;
	int c=0;
	int d=1;
	
	while (1)
	{		
		a++;
		c++;
		
		if(c>b)
		{
			d++;
			b=b*10;
		}
		if(a==5)
		{
			a=1;
		}
		OLED_ShowNum(a, 1, c, d);
		Delay_ms(1);
	}
}
