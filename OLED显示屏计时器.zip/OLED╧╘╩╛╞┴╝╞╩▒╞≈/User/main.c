#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int main(void)
{
	OLED_Init();
	
	int i=0;
	int h=0;
	int m=0;
	int s=0;
	
	while (1)
	{
		OLED_ShowNum(1, 1, h, 2);
		OLED_ShowChar(1, 3, ':');
		OLED_ShowNum(1, 4, m, 2);
		OLED_ShowChar(1, 6, ':');
		OLED_ShowNum(1, 7, s, 2);
		OLED_ShowChar(1, 9, '.');
		OLED_ShowNum(1, 10, i, 1);
		i++;
		if(i==10)
		{i=0;
			s++;
	  }
		if(s==60)
		{s=0;
			m++;
	  }
		if(m==60)
		{m=0;
			h++;
	  }
		Delay_ms(100);
	}
}
